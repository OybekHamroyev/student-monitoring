# University Admin Dashboard

A comprehensive enterprise admin dashboard for university student monitoring and management built with React, Vite, and TypeScript.

## Features

- **Authentication System**: Role-based access control (Tutor, Vice Dean, Dean, Admin)
- **Student Management**: Complete student profile management with 15+ information sections
- **Group Management**: Create and manage student groups
- **Tutor Management**: Assign tutors to groups and manage assignments
- **Search & Filter**: Advanced filtering and search capabilities
- **Audit Logging**: Track all system activities and changes
- **Dark/Light Mode**: Full theme support
- **Responsive Design**: Mobile-first design approach
- **Real-time Notifications**: Toast notifications system
- **Form Validation**: Comprehensive form validation with Zod schemas

## Tech Stack

- **Frontend Framework**: React 19.2.4
- **Build Tool**: Vite 5.0.10
- **Language**: TypeScript 5.7.3
- **State Management**: Redux Toolkit
- **Data Fetching**: TanStack Query (React Query)
- **HTTP Client**: Axios
- **Form Management**: React Hook Form
- **Validation**: Zod
- **Styling**: Tailwind CSS 4.2.0
- **UI Components**: shadcn/ui
- **Icons**: Lucide React
- **Routing**: React Router DOM 6.20.1

## Project Structure

```
src/
├── api/                 # API client and services
├── components/          # React components
│   ├── forms/          # Form components
│   ├── shared/         # Shared UI components
│   ├── table/          # Table components
│   ├── profile/        # Profile components
│   └── ui/             # Base UI components (shadcn)
├── constants/          # Application constants
├── hooks/              # Custom React hooks
├── layouts/            # Layout components
├── lib/                # Utility functions
├── pages/              # Page components
├── schemas/            # Zod validation schemas
├── services/           # API services
├── store/              # Redux store and slices
├── styles/             # Global styles
├── types/              # TypeScript type definitions
└── App.tsx             # Main application component
```

## Getting Started

### Prerequisites

- Node.js 18+
- pnpm or npm

### Installation

1. Clone the repository
2. Install dependencies:

```bash
pnpm install
```

3. Create a `.env.local` file with your environment variables:

```
VITE_API_BASE_URL=http://localhost:3000/api
```

### Development

Run the development server:

```bash
pnpm dev
```

The application will be available at `http://localhost:5173`

### Building

Build for production:

```bash
pnpm build
```

Preview the production build:

```bash
pnpm preview
```

## Key Pages

- **Login** (`/login`) - Authentication page
- **Dashboard** (`/dashboard`) - Main dashboard with statistics and overview
- **Students** (`/students`) - Student list and management
- **Student Profile** (`/students/:id`) - Detailed student profile
- **Groups** (`/groups`) - Group management
- **Tutors** (`/tutors`) - Tutor management
- **Search & Filter** (`/search`) - Advanced search and filtering
- **Settings** (`/settings`) - Application settings (Dean only)
- **Audit Logs** (`/audit`) - System activity logs (Dean only)

## State Management

The application uses Redux Toolkit for global state management:

- **auth**: User authentication and profile
- **ui**: UI state (sidebar, mobile menu)
- **theme**: Theme mode (light/dark/system)
- **dialogs**: Dialog management
- **notifications**: Toast notifications
- **filters**: Active filters
- **language**: Current language

## Custom Hooks

- `useAuth()` - Authentication state and methods
- `useNotification()` - Create toast notifications
- `useDialog()` - Manage dialog states
- `useFilter()` - Filter data arrays
- `usePagination()` - Paginate data
- `useSearch()` - Search functionality
- `useSortable()` - Sort data arrays

## Form Components

- `TextInput` - Text input field
- `SelectInput` - Select dropdown
- `TextAreaInput` - Textarea field
- `CheckboxInput` - Checkbox field
- `FileUploadInput` - File upload
- `FormField` - React Hook Form wrapper
- `FormContainer` - Form card container

## API Integration

The application uses Axios for HTTP requests with:

- Request/response interceptors
- Automatic token handling
- Error handling
- Retry logic

Configure the API base URL in `.env.local`:

```
VITE_API_BASE_URL=your_api_url
```

## Validation

Form validation is done using Zod schemas:

- `loginSchema` - Login form validation
- `studentCreateSchema` - Student creation validation
- `personalInfoSchema` - Personal information validation
- And more in `src/schemas/`

## Styling

The application uses Tailwind CSS with:

- CSS variables for theming
- Light and dark mode support
- Semantic design tokens
- Responsive utilities

## Contributing

1. Create a feature branch
2. Make your changes
3. Submit a pull request

## License

MIT
