import { useDispatch, useSelector } from 'react-redux'
import { RootState, AppDispatch } from '@/store'
import { setTheme } from '@/store/slices/theme'
import { logout } from '@/store/slices/auth'
import { Moon, Sun, LogOut } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Header() {
  const dispatch = useDispatch<AppDispatch>()
  const { user } = useSelector((state: RootState) => state.auth)
  const { mode } = useSelector((state: RootState) => state.theme)

  const handleThemeToggle = () => {
    const newTheme = mode === 'dark' ? 'light' : 'dark'
    dispatch(setTheme(newTheme))
  }

  const handleLogout = () => {
    dispatch(logout())
  }

  return (
    <header className="border-b border-border bg-card px-4 md:px-6 py-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <h2 className="text-lg font-semibold text-foreground">
          Welcome, {user?.name}
        </h2>
      </div>

      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={handleThemeToggle}
          className="p-2"
        >
          {mode === 'dark' ? (
            <Sun className="h-5 w-5" />
          ) : (
            <Moon className="h-5 w-5" />
          )}
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={handleLogout}
          className="p-2"
        >
          <LogOut className="h-5 w-5" />
        </Button>
      </div>
    </header>
  )
}
