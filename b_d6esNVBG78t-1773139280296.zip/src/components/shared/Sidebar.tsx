import { useDispatch, useSelector } from 'react-redux'
import { Link, useLocation } from 'react-router-dom'
import { RootState, AppDispatch } from '@/store'
import { toggleSidebar } from '@/store/slices/ui'
import { MENU_ITEMS, USER_ROLES } from '@/constants'
import { Menu } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function Sidebar() {
  const dispatch = useDispatch<AppDispatch>()
  const location = useLocation()
  const { sidebarCollapsed } = useSelector((state: RootState) => state.ui)
  const { user } = useSelector((state: RootState) => state.auth)
  
  const visibleItems = MENU_ITEMS.filter(item => 
    user?.role && item.roles.includes(user.role as any)
  )

  return (
    <aside className={cn(
      'bg-card border-r border-border transition-all duration-300',
      sidebarCollapsed ? 'w-20' : 'w-64'
    )}>
      <div className="flex h-16 items-center justify-between px-4">
        {!sidebarCollapsed && (
          <h1 className="text-xl font-bold text-foreground">Admin</h1>
        )}
        <button
          onClick={() => dispatch(toggleSidebar())}
          className="p-2 hover:bg-muted rounded-lg transition-colors"
        >
          <Menu className="h-5 w-5" />
        </button>
      </div>

      <nav className="space-y-2 p-4">
        {visibleItems.map((item) => {
          const isActive = location.pathname === item.href
          return (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2 transition-colors',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-foreground hover:bg-muted'
              )}
              title={sidebarCollapsed ? item.label : undefined}
            >
              <span className="h-5 w-5">{item.icon}</span>
              {!sidebarCollapsed && <span>{item.label}</span>}
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}
