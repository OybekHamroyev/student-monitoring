export const USER_ROLES = {
  TUTOR: 'tutor',
  VICE_DEAN: 'vice_dean',
  DEAN: 'dean',
  ADMIN: 'admin',
} as const

export const STUDENT_STATUSES = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  GRADUATED: 'graduated',
  SUSPENDED: 'suspended',
} as const

export const PROFICIENCY_LEVELS = {
  BEGINNER: 'beginner',
  INTERMEDIATE: 'intermediate',
  ADVANCED: 'advanced',
  NATIVE: 'native',
} as const

export const MENU_ITEMS = [
  {
    label: 'Dashboard',
    icon: 'LayoutDashboard',
    href: '/dashboard',
    roles: [USER_ROLES.TUTOR, USER_ROLES.VICE_DEAN, USER_ROLES.DEAN],
  },
  {
    label: 'Groups',
    icon: 'Users',
    href: '/groups',
    roles: [USER_ROLES.VICE_DEAN, USER_ROLES.DEAN],
  },
  {
    label: 'Students',
    icon: 'BookOpen',
    href: '/students',
    roles: [USER_ROLES.TUTOR, USER_ROLES.VICE_DEAN, USER_ROLES.DEAN],
  },
  {
    label: 'Search & Filter',
    icon: 'Search',
    href: '/search',
    roles: [USER_ROLES.VICE_DEAN, USER_ROLES.DEAN],
  },
  {
    label: 'Tutors',
    icon: 'UserCheck',
    href: '/tutors',
    roles: [USER_ROLES.VICE_DEAN, USER_ROLES.DEAN],
  },
  {
    label: 'Settings',
    icon: 'Settings',
    href: '/settings',
    roles: [USER_ROLES.DEAN],
  },
  {
    label: 'Audit Logs',
    icon: 'FileText',
    href: '/audit',
    roles: [USER_ROLES.DEAN],
  },
]

export const RELATIONSHIPS = [
  'Father',
  'Mother',
  'Brother',
  'Sister',
  'Grandmother',
  'Grandfather',
  'Other',
]

export const BLOOD_TYPES = ['A', 'B', 'AB', 'O', 'A-', 'B-', 'AB-', 'O-']

export const COUNTRIES = [
  'Afghanistan',
  'Albania',
  'Algeria',
  'Uzbekistan',
  'United States',
  'United Kingdom',
  'Russia',
  'China',
  'Japan',
  'India',
]

export const PAGINATION_LIMITS = {
  SMALL: 10,
  MEDIUM: 25,
  LARGE: 50,
} as const
