import { ReactNode } from 'react'
import { useSelector } from 'react-redux'
import { RootState } from '@/store'
import Sidebar from '@/components/shared/Sidebar'
import Header from '@/components/shared/Header'

interface AppShellProps {
  children: ReactNode
}

export default function AppShell({ children }: AppShellProps) {
  const { sidebarCollapsed } = useSelector((state: RootState) => state.ui)

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto">
          <div className="p-4 md:p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
