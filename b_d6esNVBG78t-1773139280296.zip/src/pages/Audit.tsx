import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Search } from 'lucide-react'

export default function Audit() {
  const [searchQuery, setSearchQuery] = useState('')

  const [logs] = useState([
    {
      id: '1',
      timestamp: '2024-03-10 10:30 AM',
      user: 'Admin User',
      action: 'Updated Profile',
      entity: 'Student',
      changes: 'Email changed',
    },
    {
      id: '2',
      timestamp: '2024-03-10 09:15 AM',
      user: 'Dean User',
      action: 'Created Group',
      entity: 'Group',
      changes: 'New group 2024-04 created',
    },
    {
      id: '3',
      timestamp: '2024-03-09 04:00 PM',
      user: 'Tutor User',
      action: 'Submitted Profile',
      entity: 'Student',
      changes: 'Profile marked complete',
    },
  ])

  const filteredLogs = logs.filter(
    log =>
      log.user.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.entity.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Audit Logs</h1>
        <p className="text-muted-foreground mt-2">Monitor system activity and changes</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Activity Log</CardTitle>
          <CardDescription>All system activities and modifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by user, action, or entity..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="border border-border rounded-lg overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted border-b border-border">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Timestamp</th>
                  <th className="px-4 py-3 text-left font-medium">User</th>
                  <th className="px-4 py-3 text-left font-medium">Action</th>
                  <th className="px-4 py-3 text-left font-medium">Entity</th>
                  <th className="px-4 py-3 text-left font-medium">Changes</th>
                </tr>
              </thead>
              <tbody>
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="border-b border-border hover:bg-muted/50">
                    <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{log.timestamp}</td>
                    <td className="px-4 py-3">{log.user}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs font-medium">
                        {log.action}
                      </span>
                    </td>
                    <td className="px-4 py-3">{log.entity}</td>
                    <td className="px-4 py-3 text-muted-foreground">{log.changes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-between items-center pt-4">
            <p className="text-sm text-muted-foreground">
              Showing {filteredLogs.length} of {logs.length} entries
            </p>
            <div className="flex gap-2">
              <button className="px-3 py-1 text-sm border border-border rounded hover:bg-muted">Previous</button>
              <button className="px-3 py-1 text-sm border border-border rounded hover:bg-muted">Next</button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
