import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Users, BookOpen, CheckCircle, AlertCircle } from 'lucide-react'

export default function Dashboard() {
  const [stats] = useState([
    {
      title: 'Total Students',
      value: '248',
      icon: Users,
      color: 'bg-blue-100 text-blue-600',
    },
    {
      title: 'Active Groups',
      value: '12',
      icon: BookOpen,
      color: 'bg-green-100 text-green-600',
    },
    {
      title: 'Profile Completion',
      value: '78%',
      icon: CheckCircle,
      color: 'bg-purple-100 text-purple-600',
    },
    {
      title: 'Incomplete Profiles',
      value: '54',
      icon: AlertCircle,
      color: 'bg-orange-100 text-orange-600',
    },
  ])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Overview of student management and progress
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const IconComponent = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <div className={`p-2 rounded-lg ${stat.color}`}>
                  <IconComponent className="h-4 w-4" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Main Content Area */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Completion Overview</CardTitle>
            <CardDescription>Profile completion distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { label: '100% Complete', value: 195, color: 'bg-green-500' },
                { label: '75-99%', value: 35, color: 'bg-yellow-500' },
                { label: '50-74%', value: 12, color: 'bg-orange-500' },
                { label: '< 50%', value: 6, color: 'bg-red-500' },
              ].map((item) => (
                <div key={item.label}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-foreground">{item.label}</span>
                    <span className="text-muted-foreground">{item.value}</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className={`h-full ${item.color}`}
                      style={{ width: `${(item.value / 248) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest updates and changes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { action: 'Updated student profile', student: 'Ali Abdullayev', time: '2 hours ago' },
                { action: 'Created new group', student: 'Group 2024-01', time: '5 hours ago' },
                { action: 'Marked as incomplete', student: 'Emma Wilson', time: '1 day ago' },
              ].map((activity, idx) => (
                <div key={idx} className="flex justify-between text-sm border-b border-border pb-3 last:border-b-0">
                  <div>
                    <p className="text-foreground font-medium">{activity.action}</p>
                    <p className="text-muted-foreground text-xs">{activity.student}</p>
                  </div>
                  <p className="text-muted-foreground text-xs">{activity.time}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
