import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Filter, Download } from 'lucide-react'

export default function Search() {
  const [filters, setFilters] = useState({
    search: '',
    status: 'all',
    group: 'all',
    completion: 'all',
  })

  const [results] = useState([
    { id: '1', name: 'Ali Abdullayev', group: 'Group 2024-01', completion: 95, status: 'active' },
    { id: '2', name: 'Emma Wilson', group: 'Group 2024-02', completion: 65, status: 'active' },
  ])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Search & Filter</h1>
        <p className="text-muted-foreground mt-2">Find and filter students with advanced options</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Search Filters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Search</label>
              <Input
                placeholder="Name or HEMIS ID"
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Status</label>
              <select className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground">
                <option>All Statuses</option>
                <option>Active</option>
                <option>Inactive</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Group</label>
              <select className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground">
                <option>All Groups</option>
                <option>Group 2024-01</option>
                <option>Group 2024-02</option>
              </select>
            </div>
            <div className="flex items-end gap-2">
              <Button variant="outline" className="flex-1" size="sm">
                <Filter className="h-4 w-4" />
              </Button>
              <Button variant="outline" className="flex-1" size="sm">
                Reset
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Results</CardTitle>
            <CardDescription>Found {results.length} students</CardDescription>
          </div>
          <Button size="sm" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </CardHeader>
        <CardContent>
          <div className="border border-border rounded-lg overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted border-b border-border">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Name</th>
                  <th className="px-4 py-3 text-left font-medium">Group</th>
                  <th className="px-4 py-3 text-center font-medium">Completion</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {results.map((student) => (
                  <tr key={student.id} className="border-b border-border hover:bg-muted/50">
                    <td className="px-4 py-3">{student.name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{student.group}</td>
                    <td className="px-4 py-3 text-center">{student.completion}%</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                        {student.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
