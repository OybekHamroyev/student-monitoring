import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Switch } from '@/components/ui/switch'

export default function Settings() {
  const [settings, setSettings] = useState({
    pnflRequired: true,
    contractModuleEnabled: false,
  })

  const handleSave = () => {
    console.log('Settings saved:', settings)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dean Settings</h1>
        <p className="text-muted-foreground mt-2">Configure application settings</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>System Configuration</CardTitle>
          <CardDescription>Global settings for the application</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">PNFL Requirement</p>
              <p className="text-sm text-muted-foreground">Require PNFL documents for all students</p>
            </div>
            <Switch
              checked={settings.pnflRequired}
              onCheckedChange={(checked) => setSettings({ ...settings, pnflRequired: checked })}
            />
          </div>

          <div className="border-t border-border pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Contract Module</p>
                <p className="text-sm text-muted-foreground">Enable contract management module</p>
              </div>
              <Switch
                checked={settings.contractModuleEnabled}
                onCheckedChange={(checked) => setSettings({ ...settings, contractModuleEnabled: checked })}
              />
            </div>
          </div>

          <div className="border-t border-border pt-6 flex gap-4 justify-end">
            <Button variant="outline">Cancel</Button>
            <Button onClick={handleSave}>Save Settings</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
