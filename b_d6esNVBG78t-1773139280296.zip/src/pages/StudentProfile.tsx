import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ProfileHeader } from '@/components/profile/ProfileHeader'
import { CollapsibleSection } from '@/components/profile/CollapsibleSection'
import { User, BookOpen, MapPin, Heart, Languages, Trophy, Phone, FileText, Users, Shield, Home } from 'lucide-react'

export default function StudentProfile() {
  const [isSaving, setIsSaving] = useState(false)

  // Mock student data
  const student = {
    id: '1',
    name: 'Ali Abdullayev',
    email: 'ali@university.edu',
    hemisId: '2024001',
    completion: 78,
    avatar: undefined,
    personalInfo: {
      firstName: 'Ali',
      lastName: 'Abdullayev',
      dateOfBirth: '2005-03-15',
      gender: 'Male',
      nationality: 'Uzbekistan',
    },
    educationInfo: {
      program: 'Computer Science',
      enrollmentYear: 2023,
      expectedGraduation: 2027,
      gpa: 3.8,
    },
    addressInfo: {
      street: '123 Main Street',
      city: 'Tashkent',
      state: 'Tashkent Region',
      zipCode: '100000',
      country: 'Uzbekistan',
    },
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      console.log('Profile saved')
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">Student Profile</h1>
        <p className="text-muted-foreground mt-2">
          Complete and manage student information
        </p>
      </div>

      {/* Profile Header Card */}
      <ProfileHeader
        name={student.name}
        email={student.email}
        hemisId={student.hemisId}
        completion={student.completion}
      />

      {/* Sticky Action Bar */}
      <div className="sticky top-4 z-40 bg-background border-b border-border px-4 py-3 rounded-lg flex gap-4 justify-end shadow-lg">
        <Button variant="outline" disabled={isSaving}>
          Reset
        </Button>
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>

      {/* Profile Sections */}
      <div className="space-y-4">
        <CollapsibleSection
          title="Personal Information"
          icon={<User className="h-5 w-5" />}
          defaultOpen={true}
          completed={!!student.personalInfo}
        >
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm text-muted-foreground">First Name</label>
              <p className="font-medium">{student.personalInfo.firstName}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Last Name</label>
              <p className="font-medium">{student.personalInfo.lastName}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Date of Birth</label>
              <p className="font-medium">{student.personalInfo.dateOfBirth}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Gender</label>
              <p className="font-medium">{student.personalInfo.gender}</p>
            </div>
            <div className="md:col-span-2">
              <label className="text-sm text-muted-foreground">Nationality</label>
              <p className="font-medium">{student.personalInfo.nationality}</p>
            </div>
          </div>
        </CollapsibleSection>

        <CollapsibleSection
          title="Education Information"
          icon={<BookOpen className="h-5 w-5" />}
          completed={!!student.educationInfo}
        >
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="text-sm text-muted-foreground">Program</label>
              <p className="font-medium">{student.educationInfo.program}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Enrollment Year</label>
              <p className="font-medium">{student.educationInfo.enrollmentYear}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Expected Graduation</label>
              <p className="font-medium">{student.educationInfo.expectedGraduation}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">GPA</label>
              <p className="font-medium">{student.educationInfo.gpa}</p>
            </div>
          </div>
        </CollapsibleSection>

        <CollapsibleSection
          title="Address Information"
          icon={<MapPin className="h-5 w-5" />}
          completed={!!student.addressInfo}
        >
          <div className="grid gap-4 md:grid-cols-2">
            <div className="md:col-span-2">
              <label className="text-sm text-muted-foreground">Street Address</label>
              <p className="font-medium">{student.addressInfo.street}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">City</label>
              <p className="font-medium">{student.addressInfo.city}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">State/Region</label>
              <p className="font-medium">{student.addressInfo.state}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Postal Code</label>
              <p className="font-medium">{student.addressInfo.zipCode}</p>
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Country</label>
              <p className="font-medium">{student.addressInfo.country}</p>
            </div>
          </div>
        </CollapsibleSection>

        <CollapsibleSection
          title="Health Information"
          icon={<Heart className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No health information added yet</p>
        </CollapsibleSection>

        <CollapsibleSection
          title="Language Skills"
          icon={<Languages className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No language skills added yet</p>
        </CollapsibleSection>

        <CollapsibleSection
          title="Achievements"
          icon={<Trophy className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No achievements added yet</p>
        </CollapsibleSection>

        <CollapsibleSection
          title="Contact Information"
          icon={<Phone className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No contact information added yet</p>
        </CollapsibleSection>

        <CollapsibleSection
          title="Hayfisand Records"
          icon={<FileText className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No records added yet</p>
        </CollapsibleSection>

        <CollapsibleSection
          title="Family Members"
          icon={<Users className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No family members added yet</p>
        </CollapsibleSection>

        <CollapsibleSection
          title="Social Status"
          icon={<Shield className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No social status information added yet</p>
        </CollapsibleSection>

        <CollapsibleSection
          title="Dormitory"
          icon={<Home className="h-5 w-5" />}
        >
          <p className="text-sm text-muted-foreground">No dormitory information added yet</p>
        </CollapsibleSection>
      </div>

      {/* Bottom Action Bar */}
      <div className="flex gap-4 justify-end py-6 border-t border-border">
        <Button variant="outline">Cancel</Button>
        <Button onClick={handleSave} disabled={isSaving}>
          {isSaving ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </div>
  )
}
