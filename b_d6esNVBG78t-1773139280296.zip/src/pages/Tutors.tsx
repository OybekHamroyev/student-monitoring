import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Plus } from 'lucide-react'

export default function Tutors() {
  const [tutors] = useState([
    { id: '1', name: 'Dr. Ahmed Khan', groups: ['Group 2024-01', 'Group 2024-02'], students: 53 },
    { id: '2', name: 'Prof. Maria Garcia', groups: ['Group 2024-03'], students: 22 },
  ])

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Tutors</h1>
          <p className="text-muted-foreground mt-2">Manage tutor assignments and groups</p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Add Tutor
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {tutors.map((tutor) => (
          <Card key={tutor.id}>
            <CardHeader>
              <CardTitle>{tutor.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Assigned Groups</p>
                <div className="flex flex-wrap gap-2">
                  {tutor.groups.map((group) => (
                    <span key={group} className="px-2 py-1 bg-secondary text-secondary-foreground rounded text-xs">
                      {group}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Students</p>
                <p className="text-2xl font-bold">{tutor.students}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">Edit</Button>
                <Button variant="outline" size="sm" className="flex-1">Delete</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
